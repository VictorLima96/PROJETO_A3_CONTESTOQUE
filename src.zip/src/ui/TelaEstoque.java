package ui;

import utils.KonamiListener;

import javax.swing.*;

public class TelaEstoque extends JFrame {

    public TelaEstoque() {
        setTitle("Controle de Estoque");
        setSize(600, 400);
        setLayout(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JButton btnCadUsu = new JButton("Cadastrar Usuário");
        btnCadUsu.setBounds(180, 50, 220, 40);
        btnCadUsu.addActionListener(e -> new TelaCadastroUsuario().setVisible(true));
        add(btnCadUsu);

        JButton btnCadProd = new JButton("Cadastrar Produto");
        btnCadProd.setBounds(180, 120, 220, 40);
        btnCadProd.addActionListener(e -> new TelaCadastroProduto().setVisible(true));
        add(btnCadProd);

        addKeyListener(new KonamiListener(this));
        setFocusable(true);
    }
}