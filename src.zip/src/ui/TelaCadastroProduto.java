package ui;

import dao.ProdutoDAO;
import model.Produto;

import javax.swing.*;
import java.awt.event.ActionEvent;

public class TelaCadastroProduto extends JFrame {

    private final JTextField txtNome;
    private final JTextField txtQtd;
    ProdutoDAO dao = new ProdutoDAO();

    public TelaCadastroProduto() {
        setTitle("Cadastro de Produto");
        setSize(350, 220);
        setLayout(null);
        setLocationRelativeTo(null);

        JLabel lblNome = new JLabel("Nome:");
        lblNome.setBounds(30, 20, 100, 25);
        add(lblNome);

        txtNome = new JTextField();
        txtNome.setBounds(110, 20, 180, 25);
        add(txtNome);

        JLabel lblQtd = new JLabel("Quantidade:");
        lblQtd.setBounds(30, 60, 100, 25);
        add(lblQtd);

        txtQtd = new JTextField();
        txtQtd.setBounds(110, 60, 180, 25);
        add(txtQtd);

        JButton btn = new JButton("Salvar");
        btn.setBounds(110, 110, 120, 30);
        btn.addActionListener(this::salvarProduto);
        add(btn);

        JButton btnVoltar = new JButton("Voltar");
        btnVoltar.setBounds(10, 10, 100, 30);
        btnVoltar.addActionListener(e -> {
        new TelaAdminUsuarios().setVisible(true);
        dispose();
        });
        add(btnVoltar);
    }
    
    private void salvarProduto(ActionEvent e) {
    try {
        String nome = txtNome.getText();
        int qtd = Integer.parseInt(txtQtd.getText());

        dao.salvar(new Produto(nome, qtd));

        JOptionPane.showMessageDialog(this, "Produto salvo!");
        
        // Limpar campos em vez de fechar
        txtNome.setText("");
        txtQtd.setText("");
        txtNome.requestFocus(); // Foca no primeiro campo
        
    } catch (NumberFormatException ex) {
        JOptionPane.showMessageDialog(this, "Quantidade deve ser um número!");
    }
}
}