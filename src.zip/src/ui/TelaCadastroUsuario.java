package ui;

import dao.UsuarioDAO;
import model.Usuario;

import javax.swing.*;
import java.awt.event.ActionEvent;

public class TelaCadastroUsuario extends JFrame {

    private final JTextField txtUsuario;
    private final JPasswordField txtSenha;
    private final JCheckBox chkAdmin;

    public TelaCadastroUsuario() {
        setTitle("Cadastro de Usuário");
        setSize(350, 250);
        setLayout(null);
        setLocationRelativeTo(null);
        setResizable(false);

        JLabel lblUsu = new JLabel("Usuário:");
        lblUsu.setBounds(30, 20, 100, 25);
        add(lblUsu);

        txtUsuario = new JTextField();
        txtUsuario.setBounds(110, 20, 180, 25);
        add(txtUsuario);

        JLabel lblSenha = new JLabel("Senha:");
        lblSenha.setBounds(30, 60, 100, 25);
        add(lblSenha);

        txtSenha = new JPasswordField();
        txtSenha.setBounds(110, 60, 180, 25);
        add(txtSenha);

        chkAdmin = new JCheckBox("Administrador");
        chkAdmin.setBounds(110, 95, 150, 25);
        add(chkAdmin);

        JButton btn = new JButton("Cadastrar");
        btn.setBounds(110, 140, 120, 30);
        btn.addActionListener(this::salvarUsuario);
        add(btn);

        JButton btnVoltar = new JButton("Voltar");
        btnVoltar.setBounds(10, 10, 100, 30);
        btnVoltar.addActionListener(e -> {
        new TelaAdminUsuarios().setVisible(true);
        dispose();
        });
        add(btnVoltar);
    }

    // Em TelaCadastroUsuario.java - método salvarUsuario
private void salvarUsuario(ActionEvent e) {
    String usuario = txtUsuario.getText();
    String senha = new String(txtSenha.getPassword());
    boolean admin = chkAdmin.isSelected();

    Usuario novo = new Usuario(usuario, senha, admin);
    UsuarioDAO.salvar(novo);

    JOptionPane.showMessageDialog(this, "Usuário cadastrado com êxito!");
    
     // Limpar campos
    txtUsuario.setText("");
    txtSenha.setText("");
    chkAdmin.setSelected(false);
    txtUsuario.requestFocus();
}
}