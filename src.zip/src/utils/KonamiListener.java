package utils;

import javax.swing.*;
import java.awt.*;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

public class KonamiListener extends KeyAdapter {

    private final JFrame frame;
    private final int[] konami = {
            KeyEvent.VK_UP, KeyEvent.VK_UP,
            KeyEvent.VK_DOWN, KeyEvent.VK_DOWN,
            KeyEvent.VK_LEFT, KeyEvent.VK_RIGHT,
            KeyEvent.VK_LEFT, KeyEvent.VK_RIGHT,
            KeyEvent.VK_B, KeyEvent.VK_A
    };

    private int index = 0;

    public KonamiListener(JFrame f) {
        this.frame = f;
    }

    @Override
    public void keyPressed(KeyEvent e) {
        if (e.getKeyCode() == konami[index]) {
            index++;
            if (index == konami.length) {
                ativarModoRGB();
                index = 0;
            }
        } else {
            index = 0;
        }
    }

    private void ativarModoRGB() {
        new Timer(80, e -> {
            frame.getContentPane().setBackground(
                    new Color((float) Math.random(), (float) Math.random(), (float) Math.random())
            );
        }).start();
    }
}